package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.entities.Employee;

public interface EmployeeService {
public abstract Employee save(Employee employee);
public abstract List<Employee> loadAll();
}
