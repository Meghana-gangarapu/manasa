package com.cg.service;

import java.util.List;

import com.cg.entities.Customer;

public interface CustomerService {
	public Customer save(Customer customer);

	public List<Customer> showTransactions();

	public Customer getTransaction(int rechargeId);
}
