package com.cg.dao;

import java.util.List;

import com.cg.entities.Customer;

public interface CustomerRepository {
	public Customer save(Customer customer);

	public List<Customer> showTransactions();

	public Customer getTransaction(int rechargeId);
}
