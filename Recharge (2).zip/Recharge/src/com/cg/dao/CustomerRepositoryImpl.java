package com.cg.dao;

import java.time.LocalDate;
import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.hibernate.jpa.criteria.compile.CriteriaQueryTypeQueryAdapter;
import org.springframework.stereotype.Repository;


import com.cg.entities.Customer;

@Repository
public class CustomerRepositoryImpl implements CustomerRepository{

	@PersistenceContext
	private EntityManager entityManager; 
	
	@Override
	public Customer save(Customer customer) {
		entityManager.persist(customer);
		entityManager.flush();
		return customer;
	}

	@Override
	public List<Customer> showTransactions() {
		TypedQuery<Customer> query=entityManager.createQuery("select c from Customer c",Customer.class);
		return query.getResultList();
	}

	@Override
	public Customer getTransaction(int rechargeId) {
		Customer cust=entityManager.find(Customer.class, rechargeId);
		return cust;
	}
	
}
